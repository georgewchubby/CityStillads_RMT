/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JDBC;

/**
 *
 * @author jekm
 */
public class DB {
	public static String driver = "oracle.jdbc.driver.OracleDriver";
	public static String URL = "jdbc:oracle:thin:@datdb.cphbusiness.dk:1521:dat";
	public static String ID = "jekm";
	public static String PW = "jekm";
}

