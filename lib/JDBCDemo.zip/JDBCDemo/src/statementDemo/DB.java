package statementDemo;

public class DB {

	public static String driver = "oracle.jdbc.driver.OracleDriver";
	public static String URL = "jdbc:oracle:thin:@datdb.cphbusiness.dk:1521:dat";
	public static String ID = "jekm";
	public static String PW = "jekm";
}
